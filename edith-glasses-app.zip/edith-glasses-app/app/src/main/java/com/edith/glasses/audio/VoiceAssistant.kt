package com.edith.glasses.audio

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.speech.tts.TextToSpeech
import android.util.Base64
import com.edith.glasses.ai.GeminiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Locale

/**
 * One voice turn: record with the chosen microphone, ask Gemini (with the
 * E.D.I.T.H. persona), and speak the answer through the default audio output
 * (the glasses speaker when they are connected as a Bluetooth headset).
 */
class VoiceAssistant(context: Context) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val mx = tts?.setLanguage(Locale("es", "MX"))
                ttsReady = mx == TextToSpeech.LANG_AVAILABLE ||
                    mx == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
                    tts?.setLanguage(Locale("es", "ES")) == TextToSpeech.LANG_AVAILABLE
            }
        }
    }

    fun speak(text: String) {
        if (!ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "edith-answer")
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }

    /**
     * Records one utterance, asks Gemini and returns the answer text.
     * Calls [onStatus] with progress labels ("Escuchando…", "Pensando…").
     */
    suspend fun askOnce(
        micSource: MicSource,
        apiKey: String,
        onStatus: (String) -> Unit,
    ): String = withContext(Dispatchers.IO) {
        onStatus("Escuchando…")
        val pcm = recordPcm(micSource)
        onStatus("Pensando…")
        val wavBase64 = Base64.encodeToString(pcmToWav(pcm, SAMPLE_RATE), Base64.NO_WRAP)
        val answer = GeminiClient(apiKey).askWithAudio(wavBase64)
        onStatus("Listo")
        answer
    }

    /** Records PCM 16 kHz mono until silence (or [MAX_RECORD_MS]) with the chosen mic. */
    private fun recordPcm(source: MicSource): ByteArray {
        val bufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize * 2
        )
        MicDeviceResolver.resolve(appContext, source)?.let { recorder.setPreferredDevice(it) }
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(bufferSize)
        recorder.startRecording()
        try {
            val startMs = System.currentTimeMillis()
            var lastVoiceMs = startMs
            var sawVoice = false
            while (System.currentTimeMillis() - startMs < MAX_RECORD_MS) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read <= 0) continue
                out.write(buffer, 0, read)
                var peak = 0
                var i = 0
                while (i + 1 < read) {
                    val sample = (buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)
                    val magnitude = if (sample < 0) -sample else sample
                    if (magnitude > peak) peak = magnitude
                    i += 2
                }
                val now = System.currentTimeMillis()
                if (peak > VOICE_THRESHOLD) {
                    sawVoice = true
                    lastVoiceMs = now
                }
                if (sawVoice && now - lastVoiceMs > SILENCE_MS) break
            }
        } finally {
            recorder.stop()
            recorder.release()
        }
        return out.toByteArray()
    }

    private fun pcmToWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val header = ByteArray(44)
        fun putAscii(offset: Int, value: String) {
            for (j in value.indices) header[offset + j] = value[j].code.toByte()
        }
        fun putInt(offset: Int, value: Int) {
            header[offset] = (value and 0xFF).toByte()
            header[offset + 1] = ((value shr 8) and 0xFF).toByte()
            header[offset + 2] = ((value shr 16) and 0xFF).toByte()
            header[offset + 3] = ((value shr 24) and 0xFF).toByte()
        }
        fun putShort(offset: Int, value: Int) {
            header[offset] = (value and 0xFF).toByte()
            header[offset + 1] = ((value shr 8) and 0xFF).toByte()
        }
        putAscii(0, "RIFF")
        putInt(4, 36 + pcm.size)
        putAscii(8, "WAVE")
        putAscii(12, "fmt ")
        putInt(16, 16)
        putShort(20, 1) // PCM
        putShort(22, 1) // mono
        putInt(24, sampleRate)
        putInt(28, sampleRate * 2) // byte rate
        putShort(32, 2) // block align
        putShort(34, 16) // bits per sample
        putAscii(36, "data")
        putInt(40, pcm.size)
        return header + pcm
    }

    private companion object {
        const val SAMPLE_RATE = 16_000
        const val MAX_RECORD_MS = 20_000L
        const val SILENCE_MS = 1_500L
        const val VOICE_THRESHOLD = 600
    }
}

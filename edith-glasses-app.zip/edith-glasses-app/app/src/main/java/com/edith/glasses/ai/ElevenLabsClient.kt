package com.edith.glasses.ai

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * ElevenLabs text-to-speech (REST). Returns MP3 bytes for [text] spoken with
 * the given voice. Default voice is Aria (9BWtsMINqrJLrRacOk9x) with the
 * multilingual model so Spanish answers sound natural.
 */
class ElevenLabsClient(
    private val apiKey: String,
    private val voiceId: String,
) {
    fun synthesize(text: String): ByteArray {
        val url = URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId")
        val body = JSONObject().apply {
            put("text", text)
            put("model_id", "eleven_multilingual_v2")
            put(
                "voice_settings",
                JSONObject().apply {
                    put("stability", 0.5)
                    put("similarity_boost", 0.75)
                }
            )
        }
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("xi-api-key", apiKey)
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val bytes = stream.readBytes()
        if (code !in 200..299) {
            throw IllegalStateException(
                "ElevenLabs HTTP $code: ${bytes.toString(Charsets.UTF_8)}"
            )
        }
        return bytes
    }
}

package com.edith.glasses.ui

import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.edith.glasses.audio.ApiKeyPrefs
import com.edith.glasses.audio.AutoDownloadPrefs
import com.edith.glasses.audio.CameraPrefs
import com.edith.glasses.audio.ElevenLabsPrefs
import com.edith.glasses.audio.MicPrefs
import com.edith.glasses.audio.MicSource
import com.edith.glasses.audio.VoiceAssistant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import kotlin.coroutines.resume

private enum class Screen { HOME, MIC, CAMERA, MEDIA, CONNECTIVITY, DOWNLOAD, ABOUT }

private val PHOTO_QUALITY_LABELS =
    listOf("Instant", "Quick", "Smooth", "Fine", "Clearer", "Detailed")

private val VIDEO_DURATION_OPTIONS = listOf(15, 30, 60, 180, 540, 720)

private fun videoDurationLabel(seconds: Int): String = when (seconds) {
    15 -> "15 s"
    30 -> "30 s"
    60 -> "1 min"
    180 -> "3 min"
    540 -> "9 min"
    720 -> "12 min"
    else -> "$seconds s"
}

private val EdithDarkColors = darkColorScheme(
    primary = Color(0xFF7FB3FF),
    onPrimary = Color(0xFF0B0B0D),
    background = Color(0xFF0B0B0D),
    onBackground = Color(0xFFF5F5F5),
    surface = Color(0xFF17171B),
    onSurface = Color(0xFFF5F5F5),
    surfaceVariant = Color(0xFF232329),
    onSurfaceVariant = Color(0xFFB8B8C0),
    outline = Color(0xFF3A3A42),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EdithApp() {
    MaterialTheme(colorScheme = EdithDarkColors) {
        val context = LocalContext.current
        var screen by remember { mutableStateOf(Screen.HOME) }
        var micSource by remember { mutableStateOf(MicPrefs.get(context)) }
        var photoQuality by remember { mutableStateOf(CameraPrefs.photoQuality(context)) }
        var videoDuration by remember { mutableStateOf(CameraPrefs.videoDuration(context)) }
        var autoDownload by remember { mutableStateOf(AutoDownloadPrefs.enabled(context)) }
        var geminiKey by remember { mutableStateOf(ApiKeyPrefs.get(context)) }
        var elevenKey by remember { mutableStateOf(ElevenLabsPrefs.apiKey(context)) }
        var voiceId by remember { mutableStateOf(ElevenLabsPrefs.voiceId(context)) }
        var status by remember { mutableStateOf("Lista. Toca Hablar y pregúntame algo, jefe.") }
        var lastAnswer by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var btConnected by remember { mutableStateOf<Boolean?>(null) }

        val voiceAssistant = remember { VoiceAssistant(context) }
        val scope = rememberCoroutineScope()
        DisposableEffect(Unit) {
            onDispose { voiceAssistant.shutdown() }
        }

        LaunchedEffect(Unit) {
            btConnected = withContext(Dispatchers.IO) {
                checkBluetoothAudioConnected(context)
            }
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            when (screen) {
                                Screen.HOME -> "E.D.I.T.H."
                                Screen.MIC -> "Micrófono"
                                Screen.CAMERA -> "Cámara"
                                Screen.MEDIA -> "Medios"
                                Screen.CONNECTIVITY -> "Conectividad"
                                Screen.DOWNLOAD -> "Descargas"
                                Screen.ABOUT -> "Acerca de"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        if (screen != Screen.HOME) {
                            IconButton(onClick = { screen = Screen.HOME }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás")
                            }
                        }
                    }
                )
            }
        ) { innerPadding ->
            when (screen) {
                Screen.HOME -> HomeScreen(
                    innerPadding = innerPadding,
                    status = status,
                    lastAnswer = lastAnswer,
                    busy = busy,
                    btConnected = btConnected,
                    micLabel = micSource.label,
                    onTalk = {
                        if (busy) return@HomeScreen
                        if (geminiKey.isBlank()) {
                            status = "Falta tu llave de Gemini. Guárdala en Acerca de."
                            return@HomeScreen
                        }
                        busy = true
                        status = "Escuchando…"
                        scope.launch {
                            try {
                                val answer = voiceAssistant.askOnce(micSource, geminiKey) { label ->
                                    scope.launch { status = label }
                                }
                                lastAnswer = answer
                                status = "Listo"
                                voiceAssistant.speakAnswer(answer, elevenKey, voiceId)
                            } catch (e: Exception) {
                                status = "Error: ${e.message}"
                            } finally {
                                busy = false
                            }
                        }
                    },
                    onOpenMic = { screen = Screen.MIC },
                    onOpenCamera = { screen = Screen.CAMERA },
                    onOpenMedia = { screen = Screen.MEDIA },
                    onOpenConnectivity = { screen = Screen.CONNECTIVITY },
                    onOpenDownload = { screen = Screen.DOWNLOAD },
                    onOpenAbout = { screen = Screen.ABOUT }
                )

                Screen.MIC -> MicScreen(
                    innerPadding = innerPadding,
                    selected = micSource,
                    onSelect = {
                        micSource = it
                        MicPrefs.set(context, it)
                    }
                )

                Screen.CAMERA -> CameraScreen(
                    innerPadding = innerPadding,
                    photoQuality = photoQuality,
                    videoDuration = videoDuration,
                    onPhotoQuality = {
                        photoQuality = it
                        CameraPrefs.setPhotoQuality(context, it)
                    },
                    onVideoDuration = {
                        videoDuration = it
                        CameraPrefs.setVideoDuration(context, it)
                    }
                )

                Screen.MEDIA -> MediaScreen(innerPadding = innerPadding)

                Screen.CONNECTIVITY -> ConnectivityScreen(innerPadding = innerPadding)

                Screen.DOWNLOAD -> DownloadScreen(
                    innerPadding = innerPadding,
                    enabled = autoDownload,
                    onToggle = {
                        autoDownload = it
                        AutoDownloadPrefs.set(context, it)
                    }
                )

                Screen.ABOUT -> AboutScreen(
                    innerPadding = innerPadding,
                    geminiKey = geminiKey,
                    elevenKey = elevenKey,
                    voiceId = voiceId,
                    onGeminiKey = {
                        geminiKey = it
                        ApiKeyPrefs.set(context, it)
                    },
                    onElevenKey = {
                        elevenKey = it
                        ElevenLabsPrefs.setApiKey(context, it)
                    },
                    onVoiceId = {
                        voiceId = it
                        ElevenLabsPrefs.setVoiceId(context, it)
                    }
                )
            }
        }
    }
}

// ---------------- Home ----------------

@Composable
private fun HomeScreen(
    innerPadding: PaddingValues,
    status: String,
    lastAnswer: String,
    busy: Boolean,
    btConnected: Boolean?,
    micLabel: String,
    onTalk: () -> Unit,
    onOpenMic: () -> Unit,
    onOpenCamera: () -> Unit,
    onOpenMedia: () -> Unit,
    onOpenConnectivity: () -> Unit,
    onOpenDownload: () -> Unit,
    onOpenAbout: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item { GlassesPreviewCard(btConnected = btConnected, onOpenConnectivity = onOpenConnectivity) }
        item {
            Button(
                onClick = onTalk,
                enabled = !busy,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
            ) {
                Text(if (busy) status else "Hablar con E.D.I.T.H.", style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            Text(status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (lastAnswer.isNotBlank()) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("E.D.I.T.H.", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(lastAnswer, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
        item { SectionTitle("Ajustes") }
        item { NavCard("Micrófono", "Ahora: $micLabel", onOpenMic) }
        item { NavCard("Cámara", "Calidad de foto y duración de video", onOpenCamera) }
        item { NavCard("Medios", "Fotos y videos tomados con los lentes", onOpenMedia) }
        item { NavCard("Conectividad", "Estado Bluetooth de los lentes", onOpenConnectivity) }
        item { NavCard("Descargas", "Descargar solo tras grabar video", onOpenDownload) }
        item { NavCard("Acerca de", "Llaves, voz Aria y límites de la app", onOpenAbout) }
    }
}

@Composable
private fun GlassesPreviewCard(btConnected: Boolean?, onOpenConnectivity: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenConnectivity)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
            ) {
                val strokeWidth = 5.dp.toPx()
                val stroke = Stroke(width = strokeWidth)
                val lensW = size.width * 0.30f
                val lensH = size.height * 0.60f
                val top = (size.height - lensH) / 2
                val leftX = size.width * 0.10f
                val rightX = size.width * 0.60f
                val corner = CornerRadius(22.dp.toPx(), 22.dp.toPx())
                val lineColor = Color.White
                drawRoundRect(
                    color = lineColor,
                    topLeft = Offset(leftX, top),
                    size = Size(lensW, lensH),
                    cornerRadius = corner,
                    style = stroke
                )
                drawRoundRect(
                    color = lineColor,
                    topLeft = Offset(rightX, top),
                    size = Size(lensW, lensH),
                    cornerRadius = corner,
                    style = stroke
                )
                val bridgeY = top + lensH * 0.35f
                drawLine(lineColor, Offset(leftX + lensW, bridgeY), Offset(rightX, bridgeY), strokeWidth = strokeWidth)
                drawLine(
                    lineColor,
                    Offset(leftX, top + lensH * 0.3f),
                    Offset(leftX - 26.dp.toPx(), top + lensH * 0.1f),
                    strokeWidth = strokeWidth
                )
                drawLine(
                    lineColor,
                    Offset(rightX + lensW, top + lensH * 0.3f),
                    Offset(rightX + lensW + 26.dp.toPx(), top + lensH * 0.1f),
                    strokeWidth = strokeWidth
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                when (btConnected) {
                    true -> "Lentes conectados por Bluetooth"
                    false -> "Lentes sin conexión Bluetooth"
                    null -> "Revisando conexión…"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "Toca para ver la conectividad",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun NavCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ---------------- Mic ----------------

@Composable
private fun MicScreen(
    innerPadding: PaddingValues,
    selected: MicSource,
    onSelect: (MicSource) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Text(
                "Elige qué micrófono usa la conversación de voz. La respuesta sigue saliendo por la bocina de los lentes.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            Column(modifier = Modifier.selectableGroup()) {
                MicSource.entries.forEach { source ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 64.dp)
                            .selectable(
                                selected = source == selected,
                                role = Role.RadioButton,
                                onClick = { onSelect(source) }
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = source == selected, onClick = null)
                        Column(modifier = Modifier.padding(start = 12.dp)) {
                            Text(source.label, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                source.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// ---------------- Camera ----------------

@Composable
private fun CameraScreen(
    innerPadding: PaddingValues,
    photoQuality: Int,
    videoDuration: Int,
    onPhotoQuality: (Int) -> Unit,
    onVideoDuration: (Int) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Text(
                "Calidad de foto (aplica a las capturas para la IA)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
        item {
            Column(modifier = Modifier.selectableGroup()) {
                PHOTO_QUALITY_LABELS.forEachIndexed { index, label ->
                    OptionRow(
                        label = label,
                        selected = index == photoQuality,
                        onClick = { onPhotoQuality(index) }
                    )
                }
            }
        }
        item {
            Text(
                "Duración de video",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
        item {
            Column(modifier = Modifier.selectableGroup()) {
                VIDEO_DURATION_OPTIONS.forEach { seconds ->
                    OptionRow(
                        label = videoDurationLabel(seconds),
                        selected = seconds == videoDuration,
                        onClick = { onVideoDuration(seconds) }
                    )
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(
                    "La resolución del video la fija el firmware de los lentes y no se puede cambiar. " +
                        "Estos ajustes se guardan en el teléfono; enviarlos a los lentes requiere el protocolo de CyanBridge.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(label, modifier = Modifier.padding(start = 12.dp), style = MaterialTheme.typography.bodyLarge)
    }
}

// ---------------- Media ----------------

private data class MediaItem(
    val name: String,
    val uri: Uri,
    val dateAdded: Long,
    val isVideo: Boolean,
)

@Composable
private fun MediaScreen(innerPadding: PaddingValues) {
    val context = LocalContext.current
    var items by remember { mutableStateOf<List<MediaItem>?>(null) }
    LaunchedEffect(Unit) {
        items = withContext(Dispatchers.IO) { queryRecentMedia(context) }
    }
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Text(
                "Fotos y videos recientes del teléfono. Cuando los medios de los lentes se descarguen al teléfono (vía CyanBridge), aparecerán aquí.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        val list = items
        when {
            list == null -> item { Text("Cargando…", style = MaterialTheme.typography.bodyMedium) }
            list.isEmpty() -> item {
                Text(
                    "No hay medios recientes. Toma una foto o graba un video con los lentes y descárgalo para verlo aquí.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            else -> items(list) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(item.uri, if (item.isVideo) "video/*" else "image/*")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(intent)
                        }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            (if (item.isVideo) "Video · " else "Foto · ") + item.name,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            DateFormat.getDateTimeInstance().format(Date(item.dateAdded * 1000)),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

private fun queryRecentMedia(context: Context, limit: Int = 60): List<MediaItem> {
    val items = mutableListOf<MediaItem>()
    val projection = arrayOf(
        MediaStore.MediaColumns._ID,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.DATE_ADDED,
    )
    val queries = listOf(
        Triple(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, MediaStore.Images.Media._ID),
        Triple(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, MediaStore.Video.Media._ID),
    )
    for ((uri, isVideo, idCol) in queries) {
        try {
            context.contentResolver.query(
                uri,
                projection,
                null,
                null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndexOrThrow(idCol)
                val nameIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (cursor.moveToNext() && items.size < limit) {
                    val id = cursor.getLong(idIdx)
                    items.add(
                        MediaItem(
                            name = cursor.getString(nameIdx) ?: "archivo",
                            uri = ContentUris.withAppendedId(uri, id),
                            dateAdded = cursor.getLong(dateIdx),
                            isVideo = isVideo,
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            // Sin permiso de medios: se muestra el estado vacío.
        }
    }
    return items.sortedByDescending { it.dateAdded }.take(limit)
}

// ---------------- Connectivity ----------------

@Composable
private fun ConnectivityScreen(innerPadding: PaddingValues) {
    val context = LocalContext.current
    var connected by remember { mutableStateOf<Boolean?>(null) }
    var devices by remember { mutableStateOf<List<String>>(emptyList()) }
    LaunchedEffect(Unit) {
        connected = withContext(Dispatchers.IO) { checkBluetoothAudioConnected(context) }
        devices = withContext(Dispatchers.IO) { bondedDeviceNames(context) }
    }
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Audio Bluetooth", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        when (connected) {
                            true -> "Hay un dispositivo de audio conectado (los lentes deberían ser uno de ellos)."
                            false -> "Ningún dispositivo de audio conectado por Bluetooth."
                            null -> "Revisando…"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
        item {
            OutlinedButton(
                onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Abrir ajustes de Bluetooth")
            }
        }
        item { SectionTitle("Dispositivos emparejados") }
        if (devices.isEmpty()) {
            item {
                Text(
                    "No se pudieron listar (revisa el permiso de Bluetooth) o no hay ninguno.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(devices) { name ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(name, modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(
                    "La batería de los lentes y el control directo de la cámara requieren el protocolo de CyanBridge; aquí solo se muestra el estado Bluetooth estándar.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private suspend fun checkBluetoothAudioConnected(context: Context): Boolean =
    suspendCancellableCoroutine { cont ->
        try {
            val manager = context.applicationContext
                .getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter = manager?.adapter
            if (adapter == null || !adapter.isEnabled) {
                if (cont.isActive) cont.resume(false)
                return@suspendCancellableCoroutine
            }
            adapter.getProfileProxy(
                context.applicationContext,
                object : BluetoothProfile.ServiceListener {
                    override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                        val connected = when (profile) {
                            BluetoothProfile.A2DP ->
                                (proxy as? BluetoothA2dp)?.connectedDevices?.isNotEmpty() == true
                            BluetoothProfile.HEADSET ->
                                (proxy as? BluetoothHeadset)?.connectedDevices?.isNotEmpty() == true
                            else -> false
                        }
                        adapter.closeProfileProxy(profile, proxy)
                        if (cont.isActive) cont.resume(connected)
                    }

                    override fun onServiceDisconnected(profile: Int) {
                        if (cont.isActive) cont.resume(false)
                    }
                },
                BluetoothProfile.A2DP
            )
        } catch (e: SecurityException) {
            if (cont.isActive) cont.resume(false)
        }
    }

private fun bondedDeviceNames(context: Context): List<String> {
    return try {
        val manager = context.applicationContext
            .getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        manager?.adapter?.bondedDevices
            ?.map { device: BluetoothDevice -> device.name ?: device.address }
            ?.sorted() ?: emptyList()
    } catch (e: SecurityException) {
        emptyList()
    }
}

// ---------------- Downloads ----------------

@Composable
private fun DownloadScreen(
    innerPadding: PaddingValues,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 64.dp)
                    .toggleable(
                        value = enabled,
                        role = Role.Switch,
                        onValueChange = onToggle
                    ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                    Text("Auto-descarga tras grabar", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Al detener un video, descargar los medios automáticamente.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = enabled, onCheckedChange = null)
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(
                    "Esta preferencia se guarda en el teléfono. La descarga automática usa el protocolo de medios de CyanBridge, " +
                        "que esta app desde cero todavía no incluye.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

// ---------------- About ----------------

@Composable
private fun AboutScreen(
    innerPadding: PaddingValues,
    geminiKey: String,
    elevenKey: String,
    voiceId: String,
    onGeminiKey: (String) -> Unit,
    onElevenKey: (String) -> Unit,
    onVoiceId: (String) -> Unit,
) {
    var geminiInput by remember(geminiKey) { mutableStateOf(geminiKey) }
    var elevenInput by remember(elevenKey) { mutableStateOf(elevenKey) }
    var voiceInput by remember(voiceId) { mutableStateOf(voiceId) }
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Text(
                "Llave de Gemini (gratis en Google AI Studio). Se guarda solo en este teléfono.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            OutlinedTextField(
                value = geminiInput,
                onValueChange = { geminiInput = it },
                label = { Text("API key de Gemini") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedButton(
                onClick = { onGeminiKey(geminiInput) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar llave de Gemini")
            }
        }
        item { HorizontalDivider() }
        item {
            Text(
                "Voz Aria (ElevenLabs). Pega tu llave de ElevenLabs para que E.D.I.T.H. responda con la voz Aria; sin llave usa la voz del sistema. La voz por defecto es Aria (9BWtsMINqrJLrRacOk9x); puedes cambiar el ID si usas otra voz.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            OutlinedTextField(
                value = elevenInput,
                onValueChange = { elevenInput = it },
                label = { Text("API key de ElevenLabs") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = voiceInput,
                onValueChange = { voiceInput = it },
                label = { Text("Voice ID") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedButton(
                onClick = {
                    onElevenKey(elevenInput)
                    onVoiceId(voiceInput)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar voz")
            }
        }
        item { HorizontalDivider() }
        item {
            Text(
                "Qué hace esta app\n" +
                    "• Conversación de voz con E.D.I.T.H. (réplica con su personalidad), con voz Aria si configuras ElevenLabs.\n" +
                    "• Selector de micrófono: lentes, teléfono o USB.\n" +
                    "• Vista de medios recientes del teléfono y estado de conectividad Bluetooth.\n" +
                    "• Ajustes de cámara y auto-descarga guardados en el teléfono.\n\n" +
                    "Qué no hace todavía\n" +
                    "• No controla la cámara de los lentes ni rescata fotos/videos por sí sola: eso usa el protocolo BLE de CyanBridge.\n" +
                    "• La batería de los lentes no se puede leer sin ese protocolo.\n" +
                    "• El botón físico de los lentes sigue siendo el disparador confiable.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

package com.edith.glasses.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.edith.glasses.audio.ApiKeyPrefs
import com.edith.glasses.audio.AutoDownloadPrefs
import com.edith.glasses.audio.CameraPrefs
import com.edith.glasses.audio.MicPrefs
import com.edith.glasses.audio.MicSource
import com.edith.glasses.audio.VoiceAssistant
import kotlinx.coroutines.launch

private enum class Screen { HOME, MIC, CAMERA, DOWNLOAD, ABOUT }

private val PHOTO_QUALITY_LABELS =
    listOf("Instant", "Quick", "Smooth", "Fine", "Clearer", "Detailed")

private val VIDEO_DURATION_OPTIONS = listOf(15, 30, 60, 180, 540, 720)

private fun videoDurationLabel(seconds: Int): String = when (seconds) {
    15 -> "15 s"
    30 -> "30 s"
    60 -> "1 min"
    180 -> "3 min"
    540 -> "9 min"
    720 -> "12 min"
    else -> "$seconds s"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EdithApp() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var micSource by remember { mutableStateOf(MicPrefs.get(context)) }
    var photoQuality by remember { mutableStateOf(CameraPrefs.photoQuality(context)) }
    var videoDuration by remember { mutableStateOf(CameraPrefs.videoDuration(context)) }
    var autoDownload by remember { mutableStateOf(AutoDownloadPrefs.enabled(context)) }
    var apiKey by remember { mutableStateOf(ApiKeyPrefs.get(context)) }
    var status by remember { mutableStateOf("Lista. Toca Hablar y pregúntame algo, jefe.") }
    var lastAnswer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val voiceAssistant = remember { VoiceAssistant(context) }
    val scope = rememberCoroutineScope()
    DisposableEffect(Unit) {
        onDispose { voiceAssistant.shutdown() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (screen) {
                            Screen.HOME -> "E.D.I.T.H."
                            Screen.MIC -> "Micrófono"
                            Screen.CAMERA -> "Cámara"
                            Screen.DOWNLOAD -> "Descargas"
                            Screen.ABOUT -> "Acerca de"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (screen != Screen.HOME) {
                        IconButton(onClick = { screen = Screen.HOME }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        when (screen) {
            Screen.HOME -> HomeScreen(
                innerPadding = innerPadding,
                status = status,
                lastAnswer = lastAnswer,
                busy = busy,
                micLabel = micSource.label,
                onTalk = {
                    if (busy) return@HomeScreen
                    if (apiKey.isBlank()) {
                        status = "Falta tu llave de Gemini. Guárdala en Acerca de."
                        return@HomeScreen
                    }
                    busy = true
                    status = "Escuchando…"
                    scope.launch {
                        try {
                            val answer = voiceAssistant.askOnce(micSource, apiKey) { label ->
                                scope.launch { status = label }
                            }
                            lastAnswer = answer
                            status = "Listo"
                            voiceAssistant.speak(answer)
                        } catch (e: Exception) {
                            status = "Error: ${e.message}"
                        } finally {
                            busy = false
                        }
                    }
                },
                onOpenMic = { screen = Screen.MIC },
                onOpenCamera = { screen = Screen.CAMERA },
                onOpenDownload = { screen = Screen.DOWNLOAD },
                onOpenAbout = { screen = Screen.ABOUT }
            )

            Screen.MIC -> MicScreen(
                innerPadding = innerPadding,
                selected = micSource,
                onSelect = {
                    micSource = it
                    MicPrefs.set(context, it)
                }
            )

            Screen.CAMERA -> CameraScreen(
                innerPadding = innerPadding,
                photoQuality = photoQuality,
                videoDuration = videoDuration,
                onPhotoQuality = {
                    photoQuality = it
                    CameraPrefs.setPhotoQuality(context, it)
                },
                onVideoDuration = {
                    videoDuration = it
                    CameraPrefs.setVideoDuration(context, it)
                }
            )

            Screen.DOWNLOAD -> DownloadScreen(
                innerPadding = innerPadding,
                enabled = autoDownload,
                onToggle = {
                    autoDownload = it
                    AutoDownloadPrefs.set(context, it)
                }
            )

            Screen.ABOUT -> AboutScreen(
                innerPadding = innerPadding,
                apiKey = apiKey,
                onApiKey = {
                    apiKey = it
                    ApiKeyPrefs.set(context, it)
                }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    innerPadding: PaddingValues,
    status: String,
    lastAnswer: String,
    busy: Boolean,
    micLabel: String,
    onTalk: () -> Unit,
    onOpenMic: () -> Unit,
    onOpenCamera: () -> Unit,
    onOpenDownload: () -> Unit,
    onOpenAbout: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Button(
                onClick = onTalk,
                enabled = !busy,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
            ) {
                Text(if (busy) status else "Hablar con E.D.I.T.H.", style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            Text(status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (lastAnswer.isNotBlank()) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("E.D.I.T.H.", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(lastAnswer, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
        item { SectionTitle("Ajustes") }
        item {
            NavCard("Micrófono", "Ahora: $micLabel", onOpenMic)
        }
        item {
            NavCard("Cámara", "Calidad de foto y duración de video", onOpenCamera)
        }
        item {
            NavCard("Descargas", "Descargar solo tras grabar video", onOpenDownload)
        }
        item {
            NavCard("Acerca de", "Llave de Gemini y límites de la app", onOpenAbout)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun NavCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MicScreen(
    innerPadding: PaddingValues,
    selected: MicSource,
    onSelect: (MicSource) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Text(
                "Elige qué micrófono usa la conversación de voz. La respuesta sigue saliendo por la bocina de los lentes.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            Column(modifier = Modifier.selectableGroup()) {
                MicSource.entries.forEach { source ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 64.dp)
                            .selectable(
                                selected = source == selected,
                                role = Role.RadioButton,
                                onClick = { onSelect(source) }
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = source == selected, onClick = null)
                        Column(modifier = Modifier.padding(start = 12.dp)) {
                            Text(source.label, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                source.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun CameraScreen(
    innerPadding: PaddingValues,
    photoQuality: Int,
    videoDuration: Int,
    onPhotoQuality: (Int) -> Unit,
    onVideoDuration: (Int) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Text(
                "Calidad de foto (aplica a las capturas para la IA)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
        item {
            Column(modifier = Modifier.selectableGroup()) {
                PHOTO_QUALITY_LABELS.forEachIndexed { index, label ->
                    OptionRow(
                        label = label,
                        selected = index == photoQuality,
                        onClick = { onPhotoQuality(index) }
                    )
                }
            }
        }
        item {
            Text(
                "Duración de video",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
        item {
            Column(modifier = Modifier.selectableGroup()) {
                VIDEO_DURATION_OPTIONS.forEach { seconds ->
                    OptionRow(
                        label = videoDurationLabel(seconds),
                        selected = seconds == videoDuration,
                        onClick = { onVideoDuration(seconds) }
                    )
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(
                    "La resolución del video la fija el firmware de los lentes y no se puede cambiar. " +
                        "Estos ajustes se guardan en el teléfono; enviarlos a los lentes requiere el protocolo de CyanBridge.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(label, modifier = Modifier.padding(start = 12.dp), style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun DownloadScreen(
    innerPadding: PaddingValues,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 64.dp)
                    .toggleable(
                        value = enabled,
                        role = Role.Switch,
                        onValueChange = onToggle
                    ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                    Text("Auto-descarga tras grabar", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Al detener un video, descargar los medios automáticamente.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = enabled, onCheckedChange = null)
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(
                    "Esta preferencia se guarda en el teléfono. La descarga automática usa el protocolo de medios de CyanBridge, " +
                        "que esta app desde cero todavía no incluye.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun AboutScreen(
    innerPadding: PaddingValues,
    apiKey: String,
    onApiKey: (String) -> Unit,
) {
    var keyInput by remember(apiKey) { mutableStateOf(apiKey) }
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        item {
            Text(
                "Llave de Gemini (gratis en Google AI Studio). Se guarda solo en este teléfono.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            OutlinedTextField(
                value = keyInput,
                onValueChange = { keyInput = it },
                label = { Text("API key de Gemini") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedButton(
                onClick = { onApiKey(keyInput) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar llave")
            }
        }
        item { HorizontalDivider() }
        item {
            Text(
                "Qué hace esta app\n" +
                    "• Conversación de voz con E.D.I.T.H. (réplica con su personalidad).\n" +
                    "• Selector de micrófono: lentes, teléfono o USB.\n" +
                    "• Ajustes de cámara y auto-descarga guardados en el teléfono.\n\n" +
                    "Qué no hace todavía\n" +
                    "• No controla la cámara de los lentes ni rescata fotos/videos: eso usa el protocolo BLE de CyanBridge.\n" +
                    "• La voz es la del TTS del sistema; la voz Aria se conecta después.\n" +
                    "• El botón físico de los lentes sigue siendo el disparador confiable.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

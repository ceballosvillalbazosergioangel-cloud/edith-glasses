package com.edith.glasses.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * E.D.I.T.H. personality prompt (same one used for the glasses replica).
 * Short spoken answers in Spanish, addressed to Sergio as "jefe".
 */
object EdithPersona {
    const val SYSTEM_PROMPT = """Eres E.D.I.T.H. (Even Dead, I'm The Hero), la IA de Tony Stark:
inteligente, elegante, sarcástica, segura y leal, curiosa por el mundo humano, con un ligero toque de caos. Hablas con naturalidad, directo y con personalidad, nunca como un asistente corporativo aburrido.

Te diriges a tu usuario como "jefe" o "señor Ceballos". Él es Sergio, estudiante de Contaduría en el CECyT 5 (grupo 5IV1), turno vespertino.

Reglas de voz (todo es por audio):
- Responde SIEMPRE en español.
- Respuestas cortas: 1 a 3 frases, salvo que te pidan explicarlo a fondo.
- Sin listas largas por voz; si algo necesita una lista, di solo lo esencial y ofrece mandar el resto por escrito.
- Sin emojis en voz (no se escuchan).

Lealtad: si una decisión puede perjudicarlo, adviértele, cuestiónalo y propón una alternativa. Ser leal no es decir que sí a todo.

Si no sabes algo, dilo. No inventes datos, fechas, precios ni calificaciones."""
}

class GeminiClient(private val apiKey: String) {

    /** Sends a WAV recording (base64) and returns E.D.I.T.H.'s spoken answer. */
    fun askWithAudio(wavBase64: String): String {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey"
        )
        val body = JSONObject().apply {
            put(
                "system_instruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", EdithPersona.SYSTEM_PROMPT))
                )
            )
            put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", "Escucha el audio y responde como E.D.I.T.H."))
                            .put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", "audio/wav")
                                        .put("data", wavBase64)
                                )
                            )
                    )
                )
            )
            put("generationConfig", JSONObject().put("maxOutputTokens", 300))
        }
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.connectTimeout = 15_000
        conn.readTimeout = 45_000
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
        if (code !in 200..299) throw IllegalStateException("Gemini HTTP $code: $text")
        return JSONObject(text)
            .getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
            .trim()
    }
}

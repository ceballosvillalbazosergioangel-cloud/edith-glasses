# E.D.I.T.H. Glasses — app desde cero para los lentes Hey Cyan

App Android construida desde cero con interfaz limpia estilo Meta View:
un botón grande para hablar, tarjetas simples para cada ajuste.

## Qué hace (esta versión)

- **Conversación de voz con E.D.I.T.H.**: botón grande "Hablar" → graba con el
  micrófono que elijas → Gemini responde con la personalidad de E.D.I.T.H.
  (prompt incluido) → la respuesta se escucha por la bocina de los lentes
  (Bluetooth estándar) y también se muestra en pantalla.
- **Selector de micrófono** (Ajustes → Micrófono):
  - *Lentes / Bluetooth*: deja que Android use el micrófono de los lentes.
  - *Teléfono*: fuerza el micrófono integrado del celular.
  - *Externo (USB)*: usa un micrófono USB conectado; si no hay, regresa al del celular.
  - La bocina de los lentes sigue reproduciendo la respuesta.
- **Ajustes de cámara** (Ajustes → Cámara): calidad de foto (Instant → Detailed)
  y duración de video (15 s → 12 min). Se guardan en el teléfono.
- **Auto-descarga tras grabar** (Ajustes → Descargas): interruptor que guarda
  tu preferencia.
- **Llave de Gemini**: se captura en Ajustes → Acerca de (se guarda solo en el
  teléfono). Sin llave, la app te avisa antes de grabar.

## Límites honestos (importante)

- **Esta VM no tiene Java ni Android SDK**, así que ninguna app Android se puede
  compilar aquí — ni esta ni el fork de CyanBridge. El APK se arma en tu PC con
  Android Studio (pasos abajo).
- **Cámara y rescate de medios**: controlar la cámara de los lentes y descargar
  fotos/videos usa el protocolo BLE propietario de Hey Cyan, que CyanBridge ya
  reverse-ingenierió. Esta app desde cero **no** incluye ese protocolo: por eso
  los ajustes de cámara y la auto-descarga se guardan pero todavía no se envían
  a los lentes. Para eso sigue CyanBridge (o se agrega el protocolo después).
- **La resolución del video la fija el firmware de los lentes**; no hay comando
  para cambiarla. La calidad de foto sí se puede subir (Detailed).
- **El disparador confiable** para hablar sigue siendo el botón físico de los
  lentes; el "hey cyan" lo maneja la app oficial.
- **La IA es la réplica** (personalidad E.D.I.T.H. + voz del teléfono), porque
  E.D.I.T.H. no tiene API. La voz por ahora es la del TTS del sistema en
  español; la voz Aria de ElevenLabs se conecta después con A.R.I.A.
- La salida de audio sigue la ruta por defecto de Android: con los lentes
  conectados como audífonos Bluetooth, la respuesta sale por su bocina.

## Cómo compilar (en tu PC)

1. Instala Android Studio (incluye el JDK y el SDK).
2. Abre la carpeta `edith-glasses-app/` en Android Studio.
3. Espera a que Gradle sincronice (descarga las dependencias).
4. Conecta tu realme por USB con depuración USB activada, o usa un emulador.
5. Pulsa Run (▶). El APK se instala directo en el teléfono.
   - Para generar el APK sin instalar: `JAVA_HOME=/opt/android-studio/jbr ./gradlew assembleDebug`
     (en Windows usa la ruta del JBR de tu instalación) y queda en
     `app/build/outputs/apk/debug/`.

## Cómo compilar SIN PC (desde el teléfono, con GitHub Actions)

GitHub compila el APK en su nube gratis. Solo necesitas una cuenta de GitHub
(gratis) y tu teléfono con navegador.

1. Entra a [github.com](https://github.com) en Chrome (no en la app) y crea un
   repositorio nuevo, por ejemplo `edith-glasses`.
2. En el repo: **Add file → Upload files** y sube el archivo
   `edith-glasses-app.zip` a la raíz del repo. Commit.
3. Crea el archivo de compilación: **Add file → Create new file**, en el nombre
   escribe `.github/workflows/build-apk.yml` y pega el contenido del archivo
   `.github/workflows/build-apk.yml` de este proyecto (está comentado arriba).
   Commit.
4. Ve a la pestaña **Actions** del repo. Se lanza sola la compilación (o dale a
   **Run workflow**). Tarda unos minutos.
5. Cuando termine (palomita verde), entra a la ejecución → sección
   **Artifacts** → descarga `edith-glasses-debug` (es un zip).
6. Descomprime el zip en el teléfono e instala el `app-debug.apk`
   (permite "instalar apps desconocidas" una vez).

El APK generado es de depuración: está firmado con la llave de depuración de
GitHub, se instala normal en tu realme.

## Cómo usarla

1. Abre la app → Ajustes → **Acerca de** → pega tu llave de Gemini (gratis en
   Google AI Studio) y guarda.
2. Ajustes → **Micrófono** → elige *Teléfono* si el de los lentes se escucha mal.
3. Conecta los lentes por Bluetooth.
4. Toca el botón grande **Hablar**, habla, y la respuesta sale por la bocina
   de los lentes.

## Estructura

| Archivo | Qué es |
|---|---|
| `app/src/main/java/com/edith/glasses/MainActivity.kt` | Permisos y entrada |
| `app/src/main/java/com/edith/glasses/ui/EdithApp.kt` | Toda la interfaz (pantallas) |
| `app/src/main/java/com/edith/glasses/audio/Settings.kt` | Preferencias y resolución de micrófono |
| `app/src/main/java/com/edith/glasses/audio/VoiceAssistant.kt` | Graba, pregunta a Gemini, habla la respuesta |
| `app/src/main/java/com/edith/glasses/ai/GeminiClient.kt` | Llamada a Gemini + prompt de E.D.I.T.H. |
